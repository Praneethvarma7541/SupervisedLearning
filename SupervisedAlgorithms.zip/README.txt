
Prerequired platform for the execution of this program: R studio

Instructions for the execution of the program:

1) libraries required: rpart, randomForest, caret


2) Setting the path for dataset to be imported into R environment:

	setwd("PATH")

	Example: setwd("C:\\Users\\bpran\\Desktop\\spambase")